		< First: script >

		pipeline { 
		  stages {
		    stage('Deploy') {
		      environment {
			SIGNING_KEYSTORE = credentials('my-app-signing-keystore')
			SIGNING_KEY_PASSWORD = credentials('my-app-signing-password')
		      }
		      steps {
			sh './gradlew assembleRelease'
			archiveArtifacts '**/*.apk'
			androidApkUpload googleCredentialsId: 'Google Play', apkFilesPattern: '**/*-release.apk', trackName: 'beta'
		      }
		      post {
			success {
			  mail to: 'beta-testers@example.com', subject: 'New build available!', body: 'Check it out!'
			}
		      }
		    }
		  }
		  post {
		    failure {
		      // Notify developer team of the failure
		      mail to: 'android-devs@example.com', subject: 'Oops!', body: "Build ${env.BUILD_NUMBER} failed; ${env.BUILD_URL}"
		    }
		  }
		}


		< Second : script >

		agent {
			docker {
			    image 'anapsix/alpine-java'
			}
			/*docker 'anapsix/alpine-java'*/
		    }
		    stages {
			stage ("Checkout") {
			    steps {
				git url: 'https://github.com/MikeMano1994/Kalculator.git'
			    }
			}
			stage ("Compile") {
			    steps {
				sh ".gradlew compileJava"
			    }
			}
			/*stage ("UnitTest") {
			    steps {
				sh ".gradlew test"
			    }
			}*/
		    }

